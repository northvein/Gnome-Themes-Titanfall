#!/usr/bin/env bash
# ============================================================
# IMC TITAN THEME — GNOME Installation Script
# Titanfall 2 / IMC Interface Design for Ubuntu
# ============================================================
# Usage:  chmod +x install.sh && ./install.sh
# ============================================================

set -euo pipefail

RED='\033[0;31m'
CYAN='\033[0;36m'
BCYAN='\033[1;36m'
ORANGE='\033[0;33m'
GREEN='\033[0;32m'
DIM='\033[2m'
RESET='\033[0m'

THEME_NAME="IMC-Titan"
THEME_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo -e "${BCYAN}╔══════════════════════════════════════════════╗${RESET}"
echo -e "${BCYAN}║   IMC TITAN THEME — GNOME INSTALLER          ║${RESET}"
echo -e "${BCYAN}║   Titanfall 2 Interface Aesthetic            ║${RESET}"
echo -e "${BCYAN}╚══════════════════════════════════════════════╝${RESET}"
echo ""

# ── PREFLIGHT CHECKS ────────────────────────────────────────
echo -e "${CYAN}[CHECK]${RESET} Verifying environment..."

if [ "$EUID" -eq 0 ]; then
  echo -e "${RED}[ERROR]${RESET} Do not run as root. Run as your normal user."
  exit 1
fi

if ! command -v gsettings &>/dev/null; then
  echo -e "${RED}[ERROR]${RESET} gsettings not found. Is GNOME installed?"
  exit 1
fi

# ── DIRECTORIES ──────────────────────────────────────────────
GTK_USER_THEMES="$HOME/.themes"
GTK_LOCAL_THEMES="$HOME/.local/share/themes"
GNOME_SHELL_THEMES="$HOME/.local/share/gnome-shell/theme"

mkdir -p "$GTK_USER_THEMES/$THEME_NAME"
mkdir -p "$GTK_LOCAL_THEMES/$THEME_NAME"
mkdir -p "$GNOME_SHELL_THEMES"

echo -e "${CYAN}[INFO]${RESET}  Installing to $GTK_LOCAL_THEMES/$THEME_NAME"

# ── COPY THEME FILES ─────────────────────────────────────────
echo -e "${CYAN}[COPY]${RESET} GTK3 stylesheet..."
mkdir -p "$GTK_LOCAL_THEMES/$THEME_NAME/gtk-3.0"
cp "$THEME_DIR/gtk-3.0/gtk.css"     "$GTK_LOCAL_THEMES/$THEME_NAME/gtk-3.0/"
cp "$THEME_DIR/gtk-3.0/widgets.css" "$GTK_LOCAL_THEMES/$THEME_NAME/gtk-3.0/"

# Also symlink to ~/.themes for compatibility
mkdir -p "$GTK_USER_THEMES/$THEME_NAME/gtk-3.0"
cp "$THEME_DIR/gtk-3.0/gtk.css"     "$GTK_USER_THEMES/$THEME_NAME/gtk-3.0/"
cp "$THEME_DIR/gtk-3.0/widgets.css" "$GTK_USER_THEMES/$THEME_NAME/gtk-3.0/"

echo -e "${CYAN}[COPY]${RESET} GTK4 stylesheet..."
mkdir -p "$GTK_LOCAL_THEMES/$THEME_NAME/gtk-4.0"
cp "$THEME_DIR/gtk-4.0/gtk.css" "$GTK_LOCAL_THEMES/$THEME_NAME/gtk-4.0/"

# GTK4 needs theme in a special config location too
mkdir -p "$HOME/.config/gtk-4.0"
cp "$THEME_DIR/gtk-4.0/gtk.css" "$HOME/.config/gtk-4.0/gtk.css"
echo -e "${CYAN}[COPY]${RESET} GTK4 → ~/.config/gtk-4.0/gtk.css"

echo -e "${CYAN}[COPY]${RESET} GNOME Shell stylesheet..."
mkdir -p "$GTK_LOCAL_THEMES/$THEME_NAME/gnome-shell"
cp "$THEME_DIR/gnome-shell/gnome-shell.css" "$GTK_LOCAL_THEMES/$THEME_NAME/gnome-shell/"
# Also drop a copy for the shell extension loader
cp "$THEME_DIR/gnome-shell/gnome-shell.css" "$GNOME_SHELL_THEMES/"

echo -e "${CYAN}[COPY]${RESET} Theme metadata..."
cp "$THEME_DIR/index.theme" "$GTK_LOCAL_THEMES/$THEME_NAME/"
cp "$THEME_DIR/index.theme" "$GTK_USER_THEMES/$THEME_NAME/"

# ── FONT CHECK & INSTALL TIP ─────────────────────────────────
echo ""
echo -e "${CYAN}[FONT]${RESET} Checking recommended fonts..."

FONT_MISSING=()

check_font() {
  fc-list | grep -qi "$1" || FONT_MISSING+=("$1")
}

check_font "Share Tech Mono"
check_font "Exo 2"

if [ ${#FONT_MISSING[@]} -gt 0 ]; then
  echo -e "${ORANGE}[WARN]${RESET}  Missing fonts: ${FONT_MISSING[*]}"
  echo -e "${DIM}         Install with:${RESET}"
  echo -e "${DIM}         sudo apt install fonts-urw-base35 fonts-open-sans${RESET}"
  echo -e "${DIM}         Or download from Google Fonts:${RESET}"
  echo -e "${DIM}           https://fonts.google.com/specimen/Share+Tech+Mono${RESET}"
  echo -e "${DIM}           https://fonts.google.com/specimen/Exo+2${RESET}"
else
  echo -e "${GREEN}[OK]${RESET}    Fonts found."
fi

# ── APPLY VIA GSETTINGS ──────────────────────────────────────
echo ""
echo -e "${CYAN}[APPLY]${RESET} Applying theme via gsettings..."

# GTK theme
gsettings set org.gnome.desktop.interface gtk-theme    "$THEME_NAME" 2>/dev/null \
  && echo -e "${GREEN}[OK]${RESET}    GTK theme set to $THEME_NAME" \
  || echo -e "${ORANGE}[WARN]${RESET}  Could not set GTK theme automatically."

# Color scheme (prefer dark)
gsettings set org.gnome.desktop.interface color-scheme "prefer-dark" 2>/dev/null \
  && echo -e "${GREEN}[OK]${RESET}    Color scheme → prefer-dark" \
  || true

# Font
gsettings set org.gnome.desktop.interface font-name        "Exo 2 10"      2>/dev/null || true
gsettings set org.gnome.desktop.interface monospace-font-name "Share Tech Mono 11" 2>/dev/null || true
gsettings set org.gnome.desktop.interface document-font-name  "Exo 2 10"   2>/dev/null || true
echo -e "${GREEN}[OK]${RESET}    Fonts applied."

# Button layout (window decorations left: close, minimize, maximize)
gsettings set org.gnome.desktop.wm.preferences button-layout "close,minimize,maximize:appmenu" 2>/dev/null || true
echo -e "${GREEN}[OK]${RESET}    Window button layout set."

# Anti-aliasing / hinting
gsettings set org.gnome.desktop.interface font-antialiasing "rgba"    2>/dev/null || true
gsettings set org.gnome.desktop.interface font-hinting      "slight"  2>/dev/null || true

# ── GNOME SHELL THEME (needs User Themes extension) ──────────
echo ""
echo -e "${CYAN}[SHELL]${RESET} Attempting to apply GNOME Shell theme..."

if gnome-extensions list 2>/dev/null | grep -q "user-theme@gnome-shell-extensions.gcampax.github.com"; then
  gsettings set org.gnome.shell.extensions.user-theme name "$THEME_NAME" 2>/dev/null \
    && echo -e "${GREEN}[OK]${RESET}    GNOME Shell theme applied." \
    || echo -e "${ORANGE}[WARN]${RESET}  Could not apply shell theme via gsettings."
else
  echo -e "${ORANGE}[INFO]${RESET}  User Themes extension not found."
  echo -e "${DIM}         Install it to apply the GNOME Shell theme:${RESET}"
  echo -e "${DIM}         sudo apt install gnome-shell-extensions${RESET}"
  echo -e "${DIM}         Then enable: gnome-extensions enable user-theme@gnome-shell-extensions.gcampax.github.com${RESET}"
  echo -e "${DIM}         Then re-run this script.${RESET}"
fi

# ── TERMINAL COLORS ──────────────────────────────────────────
echo ""
echo -e "${CYAN}[TERM]${RESET}  Installing terminal color scheme..."
if command -v dconf &>/dev/null; then
  bash "$THEME_DIR/install-terminal-colors.sh" 2>/dev/null \
    && echo -e "${GREEN}[OK]${RESET}    GNOME Terminal colors installed." \
    || echo -e "${ORANGE}[WARN]${RESET}  Terminal color install failed (may need GNOME Terminal open)."
else
  echo -e "${DIM}         dconf not found, skipping terminal colors.${RESET}"
fi

# ── DONE ─────────────────────────────────────────────────────
echo ""
echo -e "${BCYAN}╔══════════════════════════════════════════════╗${RESET}"
echo -e "${BCYAN}║   INSTALLATION COMPLETE                      ║${RESET}"
echo -e "${BCYAN}╚══════════════════════════════════════════════╝${RESET}"
echo ""
echo -e "${GREEN}Theme files installed to:${RESET}"
echo -e "  ${DIM}$GTK_LOCAL_THEMES/$THEME_NAME${RESET}"
echo -e "  ${DIM}$GTK_USER_THEMES/$THEME_NAME${RESET}"
echo ""
echo -e "${CYAN}To fine-tune or switch themes:${RESET}"
echo -e "  ${DIM}sudo apt install gnome-tweaks && gnome-tweaks${RESET}"
echo ""
echo -e "${ORANGE}VANGUARD STATUS: ONLINE${RESET}"
echo -e "${DIM}\"The Frontier awaits, Pilot.\"${RESET}"
echo ""
