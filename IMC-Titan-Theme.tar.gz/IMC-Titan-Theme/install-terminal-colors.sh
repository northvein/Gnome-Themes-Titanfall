#!/usr/bin/env bash
# ============================================================
# IMC TITAN — Terminal Color Scheme Installer
# Applies Titanfall 2 color palette to GNOME Terminal
# ============================================================

PROFILE_NAME="IMC-Titan"
PROFILE_SLUG="imc-titan-tf2"

# GNOME Terminal dconf path
DCONF_PATH="/org/gnome/terminal/legacy/profiles:"

echo "Installing IMC-Titan terminal color scheme..."

# Create a new profile
NEW_UUID=$(uuidgen 2>/dev/null || python3 -c "import uuid; print(uuid.uuid4())")
PROFILE_PATH="$DCONF_PATH/:$NEW_UUID/"

dconf write "$DCONF_PATH/list" "$(dconf read "$DCONF_PATH/list" | sed "s/]$/, '$NEW_UUID']/" | sed "s/^\[$/['$NEW_UUID']/")"

dconf write "${PROFILE_PATH}visible-name"         "'$PROFILE_NAME'"
dconf write "${PROFILE_PATH}use-theme-colors"     "false"
dconf write "${PROFILE_PATH}use-theme-background" "false"
dconf write "${PROFILE_PATH}use-theme-transparency" "false"

# Background / foreground
dconf write "${PROFILE_PATH}background-color"     "'#050910'"
dconf write "${PROFILE_PATH}foreground-color"     "'#C8DCE8'"
dconf write "${PROFILE_PATH}bold-color"           "'#40E8FF'"
dconf write "${PROFILE_PATH}bold-color-same-as-fg" "false"

# Cursor
dconf write "${PROFILE_PATH}cursor-blink-mode"    "'on'"
dconf write "${PROFILE_PATH}cursor-shape"         "'block'"
dconf write "${PROFILE_PATH}cursor-background-color" "'#00C8E0'"
dconf write "${PROFILE_PATH}cursor-foreground-color" "'#050910'"

# Font
dconf write "${PROFILE_PATH}use-system-font"      "false"
dconf write "${PROFILE_PATH}font"                 "'Share Tech Mono 12'"

# Scrollback
dconf write "${PROFILE_PATH}scrollback-unlimited" "true"

# 16-color palette (ANSI 0–15)
# Black variants  → deep navy
# Red             → IMC red / alert
# Green           → frontier green / healthbar
# Yellow          → warning amber
# Blue            → deep tech blue
# Magenta         → BT purple (Vanguard accent)
# Cyan            → IMC energy cyan (PRIMARY accent)
# White           → text grey
PALETTE="[
  '#0A0F18',
  '#E02040',
  '#00A060',
  '#C07800',
  '#1A4C8C',
  '#6040B0',
  '#00C8E0',
  '#7A9AB0',
  '#1C2A3A',
  '#FF4060',
  '#00E080',
  '#FFB040',
  '#2068C0',
  '#8060E0',
  '#40E8FF',
  '#C8DCE8'
]"

dconf write "${PROFILE_PATH}palette" "$PALETTE"

echo "✓ IMC-Titan terminal profile installed."
echo "  Open GNOME Terminal → Preferences → Profiles → Select 'IMC-Titan'"
echo ""
echo "Profile UUID: $NEW_UUID"
